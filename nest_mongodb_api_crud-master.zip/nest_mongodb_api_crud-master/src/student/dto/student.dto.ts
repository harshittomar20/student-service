export interface StudentDTO {
    readonly name: string;
    readonly age: number;
    readonly city: string;
    readonly initial: string;
}
